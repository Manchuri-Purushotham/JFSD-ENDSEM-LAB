package KLEF.Spring_Di;

public interface Vehicle {
	
	void drive();

}
