package KLEF.Spring_Di;

public interface Manufacturer {
	
	String name();

}
