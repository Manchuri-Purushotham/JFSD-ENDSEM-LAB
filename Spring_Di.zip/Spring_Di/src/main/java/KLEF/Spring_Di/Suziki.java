package KLEF.Spring_Di;

import org.springframework.stereotype.Component;

@Component
//@Primary
public class Suziki implements Manufacturer {
	@Override
	public String name() {
		return "Suziki";
	}

}